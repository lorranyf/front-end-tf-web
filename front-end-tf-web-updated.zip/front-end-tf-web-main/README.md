# front-end-tf-web
Front-End do trabalho final da disciplina de WEB
GRUPO: Antonio Marcos, Clara Eduarda, Lindha Emanuelly, Lorrany Fábia, Samilly Rayara

Titulo: Hometasker

Link: https://front-end-tf-web-lyart.vercel.app/

Descrição: O Hometasker é o app perfeito para quem mora em casa com várias pessoas e precisa manter a organização das tarefas domésticas de forma eficiente e colaborativa. Com uma interface simples e intuitiva, o app permite que você crie, distribua e acompanhe tarefas diárias, semanais ou mensais, garantindo que cada membro da casa saiba exatamente o que precisa fazer.

principais funcionalidades: 
Criação de tarefas: Adicione tarefas personalizadas como lavar a louça, tirar o lixo, varrer o chão, entre outras.
Atribuição de tarefas: Defina quem ficará responsável por cada tarefa
Calendário compartilhado: Veja a agenda de tarefas de todos os membros da casa em um só lugar, com datas e horários organizados.
Lista de compras: Crie e compartilhe uma lista de compras com todos os moradores, permitindo que qualquer pessoa adicione itens quando necessário e marque quando já foram comprados. Ideal para manter a casa sempre abastecida sem perder tempo.